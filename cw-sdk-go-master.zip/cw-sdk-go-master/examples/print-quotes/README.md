Real-Time Quotes

```
go run print-quotes.go -apikey APIKEY -secretkey SECRETKEY -pair btcusd
```

![](https://user-images.githubusercontent.com/897596/40878780-0595509e-6653-11e8-8be8-ab4839066585.gif)
