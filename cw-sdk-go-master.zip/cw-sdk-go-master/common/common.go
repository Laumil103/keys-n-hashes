/*
Package common provides data structures used throughout the Cryptowatch SDK.
*/
package common // import "code.cryptowat.ch/cw-sdk-go/common"
