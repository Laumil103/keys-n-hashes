package version // import "code.cryptowat.ch/cw-sdk-go/version"

const (
	Version = "1.0.1"
)
