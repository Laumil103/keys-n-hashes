# Info
This is a .MOD player for bitbox ! 

This version runs mods embedded in binary, not relying on a fatfs implmentation. 
in the demo, press a button to go to next file. 

# Credits  
 * Original code by  "Pascal Piazzalunga" - http://www.serveurperso.com
 * Bitbox port : makapuf  

# Todo 
- allow python exporter to massage the mod file to avoid parsing from memory, generate C structs directly and be able to share samples.
- allow single note playing for SFX (or inject whole minipatterns ?)
