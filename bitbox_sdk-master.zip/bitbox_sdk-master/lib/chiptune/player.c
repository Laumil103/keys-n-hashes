/* Simple soundengine for the BitBox
 * Copyright 2015, Makapuf <makapuf2@gmail.com>
 * Copyright 2014-2017, Adrien Destugues <pulkomandy@pulkomandy.tk>
 * Copyright 2007, Linus Akesson
 * Based on the "Hardware Chiptune" project
 *
 * This main file is a player for the packed music format used in the original
 * "hardware chiptune"
 * http://www.linusakesson.net/hardware/chiptune.php
 * There is a tracker for this but the format here is slightly different (mostly
 * because of the different replay rate - 32KHz instead of 16KHz).
 *
 * Because of this the sound in the tracker will be a bit different, but it can
 * easily be tweaked. This version has a somewhat bigger but much simplified song format.
 */

// #define DEBUG_CHIPTUNE

#include "bitbox.h"
#include "player.h"
#include "player_internals.h"

#include <stdint.h>
#include <stdlib.h>
#include "chiptune.h"

static int16_t songwait; // >0 means wait N frames, 0 means play now. <0 means stop playing now.
static uint8_t trackpos;
static uint8_t songspeed;
static uint8_t playsong;
static uint8_t nchan; // number of active channels
static uint16_t songpos;

const uint16_t chip_freqtable[] = {
	0x010b, 0x011b, 0x012c, 0x013e, 0x0151, 0x0165, 0x017a, 0x0191, 0x01a9,
	0x01c2, 0x01dd, 0x01f9, 0x0217, 0x0237, 0x0259, 0x027d, 0x02a3, 0x02cb,
	0x02f5, 0x0322, 0x0352, 0x0385, 0x03ba, 0x03f3, 0x042f, 0x046f, 0x04b2,
	0x04fa, 0x0546, 0x0596, 0x05eb, 0x0645, 0x06a5, 0x070a, 0x0775, 0x07e6,
	0x085f, 0x08de, 0x0965, 0x09f4, 0x0a8c, 0x0b2c, 0x0bd6, 0x0c8b, 0x0d4a,
	0x0e14, 0x0eea, 0x0fcd, 0x10be, 0x11bd, 0x12cb, 0x13e9, 0x1518, 0x1659,
	0x17ad, 0x1916, 0x1a94, 0x1c28, 0x1dd5, 0x1f9b, 0x217c, 0x237a, 0x2596,
	0x27d3, 0x2a31, 0x2cb3, 0x2f5b, 0x322c, 0x3528, 0x3851, 0x3bab, 0x3f37,
	0x42f9, 0x46f5, 0x4b2d, 0x4fa6, 0x5462, 0x5967, 0x5eb7, 0x6459, 0x6a51,
	0x70a3, 0x7756, 0x7e6f, 0
};

const int8_t chip_sinetable[] = {
	0, 12, 25, 37, 49, 60, 71, 81, 90, 98, 106, 112, 117, 122, 125, 126,
	127, 126, 125, 122, 117, 112, 106, 98, 90, 81, 71, 60, 49, 37, 25, 12,
	0, -12, -25, -37, -49, -60, -71, -81, -90, -98, -106, -112, -117, -122,
	-125, -126, -127, -126, -125, -122, -117, -112, -106, -98, -90, -81,
	-71, -60, -49, -37, -25, -12
};


struct channel channel[MAX_CHANNELS];

struct ChipSong *current_song;

static void runcmd(uint8_t ch, uint8_t cmd, uint8_t param, uint8_t context) {
	// context is 0 for instrument, 1/2 for pattern
	switch(cmd) {
		case 1: // 0 = note off
			channel[ch].inum = 0;
			break;
		case 2: // d = duty cycle
			osc[ch].duty = param << 8;
			break;
		case 3: // f = volume slide
			channel[ch].volumed = param;
			break;
		case 4: // i = inertia (auto note slides)
			channel[ch].inertia = param << 1;
			break;
		case 5: // j = instrument jump
			channel[ch].iptr = param;
			break;
		case 6: // l = slide
			channel[ch].bendd = param;
			break;
		case 7: // m = duty variation
			channel[ch].dutyd = param << 6;
			break;
		case 8: // t = timing (for instrument, song speed for track context)
			if (!context)
				channel[ch].iwait = param;
			else
				songspeed = param;
			break;
		case 9: // v = volume
			osc[ch].volume = param;
			break;
		case 10: // w = select waveform
			osc[ch].waveform = param;
			break;
		case 11: // ~ = vibrato
			if(channel[ch].vdepth != (param >> 4)) {
				channel[ch].vpos = 0;
			}
			channel[ch].vdepth = param >> 4;
			channel[ch].vrate = param & 15;
			break;
		case 12: // + = set relative note
			channel[ch].inote = param + channel[ch].tnote - 12 * 4;
			break;
		case 13: // = = set absolute note in instrument context or instrument in pattern context
			if (!context)
				channel[ch].inote = param;
			else
				channel[ch].lastinstr = param;
			break;
		case 14:
			osc[ch].bitcrush=param;
	}
}

void chip_play(const struct ChipSong *song) {
	if (!song) { // if given NULL, just stop it now - don't unload
		playsong=0;
		return;
	}
	current_song = (struct ChipSong*) song;
	nchan = current_song->numchannels; // number of channels

	songwait = 0;
	trackpos = 0;
	playsong = 1;
	songpos = 0;
	songspeed=4; // default speed

	for (int i=0;i<nchan;i++) {
		osc[i].volume = 0;
		channel[i].inum = 0;
		osc[i].bitcrush = 5;
	}
}

void chip_note(uint8_t ch, uint8_t note, uint8_t instrument)
{
	channel[ch].tnote = note ;
	channel[ch].inum = instrument;
	channel[ch].iptr = 0;
	channel[ch].iwait = 0;
	channel[ch].bend = 0;
	channel[ch].bendd = 0;
	channel[ch].volumed = 0;
	channel[ch].dutyd = 0;
	channel[ch].vdepth = 0;
}

static void chip_song_update()
// this shall be called each 1/60 sec.
// one buffer is 512 samples @32kHz, which is ~ 62.5 Hz,
// calling each song frame should be OK
{
	if(songwait) {
		songwait--;
	} else {
		songwait = songspeed;

		if(!trackpos) {
			if(playsong) {
				if(songpos >= current_song->songlen) {
					playsong = 0;
					#ifdef DEBUG_CHIPTUNE
					message("Stopping song\n");
					#endif
				} else {
					#ifdef DEBUG_CHIPTUNE
					message("Now at position %d of song\n",songpos);
					#endif
					for(int ch = 0; ch < nchan; ch++) {
						// read each of the track pattern
						channel[ch].tnum = current_song->tracklist[songpos*nchan+ch];
						channel[ch].transp = current_song->transpose[songpos*nchan+ch];
					}
					songpos++;
				}
			}
		}

		if(playsong) {
			#ifdef DEBUG_CHIPTUNE
			message ("%d |",trackpos);
			#endif

			for(int ch = 0; ch < nchan; ch++) {
				if (!channel[ch].tnum)
					continue;

				uint32_t fields = current_song->tracks[channel[ch].tnum-1][trackpos];

				// field = x:1 note:7 cmd1:4 cmd2:4 par1:8 par2:8
				uint8_t note = (fields>>24) & 0x7f;
				uint8_t cmd1 = (fields>>20) & 0xf;
				uint8_t cmd2 = (fields>>16) & 0xf;
				uint8_t par1 = (fields>>8) & 0xff;
				uint8_t par2 = (fields>>0) & 0xff;
				#ifdef DEBUG_CHIPTUNE
				message("Note:%02x %x %02x / %x %02x |",note, cmd1,par1,cmd2,par2);
				#endif

				if(cmd1) runcmd(ch, cmd1, par1,1);
				if(cmd2) runcmd(ch, cmd2, par2,2);

				if(note)
					chip_note(ch,note + channel[ch].transp, channel[ch].lastinstr);

			}
			#ifdef DEBUG_CHIPTUNE
			message("\n");
			#endif

			trackpos++;
			if (trackpos == current_song->tracklength)
				trackpos = 0;
		}
	}
}

static void chip_osc_update()
{
	for(int ch = 0; ch < nchan; ch++) {
		int16_t vol;
		uint16_t duty;
		uint16_t slur;

		while(channel[ch].inum && !channel[ch].iwait) {
			// run instrument instruction iptr from instr inum  as cmd, param
			uint16_t ins = current_song->instruments[channel[ch].inum-1][channel[ch].iptr];

			channel[ch].iptr++;

			runcmd(ch, ins>>8, ins & 0xff,0);
		}

		if(channel[ch].iwait)
			channel[ch].iwait--;

		if(channel[ch].inertia) {
			int16_t diff;

			slur = channel[ch].slur;
			diff = chip_freqtable[channel[ch].inote] - slur;
			//diff >>= channel[ch].inertia;
			if(diff > 0) {
				if(diff > channel[ch].inertia) diff = channel[ch].inertia;
			} else if(diff < 0) {
				if(diff < -channel[ch].inertia) diff = -channel[ch].inertia;
			}
			slur += diff;
			channel[ch].slur = slur;
		} else {
			slur = chip_freqtable[channel[ch].inote];
		}
		osc[ch].freq =
			slur +
			channel[ch].bend +
			((channel[ch].vdepth * chip_sinetable[channel[ch].vpos & 63]) >> 2);
		channel[ch].bend += channel[ch].bendd;
		vol = osc[ch].volume + channel[ch].volumed;
		if(vol < 0) vol = 0;
		if(vol > 255) vol = 255;
		osc[ch].volume = vol;

		duty = osc[ch].duty + channel[ch].dutyd;
		if(duty > 0xe000) duty = 0x2000;
		if(duty < 0x2000) duty = 0xe000;
		osc[ch].duty = duty;

		channel[ch].vpos += channel[ch].vrate;
	}
}


void game_snd_buffer(uint16_t* buffer, int len) {
	if (current_song) {
		if (playsong)
			chip_song_update();
			// even if song is not playing, update oscillators in case a "chip_note" gets called.
		chip_osc_update();
	}
	// Just generate enough samples to fill the buffer.
	for (int i = 0; i < len; i++) {
		buffer[i] = gen_sample();
	}
}

int chip_song_playing()
{
    return (playsong != 0);
}

